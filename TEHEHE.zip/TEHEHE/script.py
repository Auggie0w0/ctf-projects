path = "/Users/augustlam/Downloads/ctf/forenscis/saved.png.zip"

with open(path, "rb") as f:
    content = f.read()

# Convert to binary: each byte -> 8 bits
binary_str = "".join(f"{b:08b}" for b in content)

# Transform: "0" -> "NON", "1" -> "OUI"
transform = {"0": "NON", "1": "OUI"}
result = "".join(transform[bit] for bit in binary_str)

output_path = "/Users/augustlam/Downloads/ctf/forenscis/bin_transformed.txt"
with open(output_path, "w", encoding="utf-8") as f:
    f.write(result)
print(f"Written to {output_path}")
