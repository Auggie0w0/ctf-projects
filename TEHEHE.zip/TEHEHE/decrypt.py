path = "/Users/augustlam/Downloads/ctf/forenscis/bin_transformed.txt"

with open(path, "r", encoding="utf-8") as f:
    content = f.read()

# Transform: "NON" -> "0", "OUI" -> "1"
binary_str = content.replace("NON", "0").replace("OUI", "1")

# Convert binary string back to bytes (8 bits per byte)
result = bytes(int(binary_str[i : i + 8], 2) for i in range(0, len(binary_str), 8))

output_path = "/Users/augustlam/Downloads/ctf/forenscis/decrypted.bin"
with open(output_path, "wb") as f:
    f.write(result)
print(f"Written to {output_path}")